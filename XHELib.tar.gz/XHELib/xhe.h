#ifndef _XHE_H
#define _XHE_H

using namespace std;


class xhe{
public:
    void encrypt(unsigned int * ct, const unsigned int * pt);
    void encrypt_matrix_once(unsigned int ** ct, unsigned int ** pt);
    void encrypt_vector_once(unsigned int ** ct, unsigned int * pt);
    void decrypt(unsigned int * pt, const unsigned int * ct);
    void decrypt_matrix_once(unsigned int ** pt, unsigned int ** ct);
    void decrypt_vector_once(unsigned int * pt, unsigned int ** ct);
    void add_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);
    void sub_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);
    void mul_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);
    void mul_ee_matrix_once(unsigned int * ct, unsigned int ** ct1, unsigned int ** ct2);
    xhe(unsigned int _logt);
    ~xhe();
    unsigned int** mem_Y;
    unsigned int logq;
    unsigned int logt;
    unsigned int logw;
    unsigned int logd;
    unsigned int m;
    unsigned int t;
    unsigned int l;
    double q;    
    unsigned int d;
    unsigned int n;
    unsigned int L;
    unsigned int w;
    double B;
    double a, sigma;
    unsigned int* seed_X;
private:
    void mul_ee_pre();
    void mul_ee_v0(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);
    void mul_ee_v1(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);
    void mul_ee_matrix_once_v0(unsigned int * ct, unsigned int ** ct1, unsigned int ** ct2);
    void mul_ee_matrix_once_v1(unsigned int * ct, unsigned int ** ct1, unsigned int ** ct2);
    unsigned int* T;

};

#endif // _XHE_H
