#include "xhe.h"
#include <time.h>
#include <limits.h>
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include <iostream>
#include <NTL/ZZ.h>

using namespace std;

#define M_PI           3.14159265358979323846
#define BILLION 1000000000L

double debugw, debugl, debugm;

unsigned int next_sample(double sigma){
    static bool generated = false;
    static double y = 0;
    static long cnt = 0;

    //Generate a pair of rv using the Box-Muller transform
    double nxt;
    if(!generated)
    {
    static const long bignum = 0xfffffff;
    double r1 = ((double) (NTL::RandomBnd(bignum) + 1)) / ((double)(bignum+1));
    double r2 = ((double) (NTL::RandomBnd(bignum) + 1)) / ((double)(bignum+1));

    double theta=2*M_PI*r1;
    double rr= sqrt(-2.0*log(r2))*sigma;
    nxt = rr*sin(theta);
    y = rr*cos(theta);

    generated = true;
    }
    else
    {
        nxt = y;
        generated = false;
    }

    double fractpart, intpart;

    fractpart = modf(nxt, &intpart);

    //cout << nxt << endl;

    if(fractpart > 0.5 && fractpart < 1)
        fractpart = fractpart - 1;
    else if(fractpart > -1 && fractpart < -0.5)
        fractpart = fractpart + 1;

    double q = (double)UINT_MAX + 1.0; 
    int ret = (int)round(fractpart * q);

    //assert(ret < debugw/2 && ret >= -debugw/2);
    //assert(ret < debugw/4 && ret >= -debugw/4);
    assert(ret*debugm < sqrt(debugw/(2 * debugl)) && ret*debugm >= -sqrt(debugw/(2 * debugl)));

    return ret;
}

xhe::xhe(unsigned int _logt)
{
    _logt = 8;

    m = 10;
    logq = sizeof(int) * 8;
    q = (double)UINT_MAX + 1.0;
    logt = _logt;
    l = 736;
    logw = logq - logt;
    logd = 8;
    d = 1 << logd;
    w = ((int)1) << logw;
    t = 1 << logt;
    n = m + l;
    L = logq / logd;

    double b_eq = 4 * t * ( 0.5 * l + 2 * sqrt(l) ), a_eq = l, neg_c_eq = w;
    double delta = b_eq * b_eq + 4 * a_eq * neg_c_eq;
    B = (-b_eq + sqrt(delta))/(2 * a_eq); 
    assert(B * B * l + b_eq * B - w < 1 && B * B * l + b_eq * B - w > -1);
    B = B / m;

    a = 1.0 * B / (6 * q);
    sigma = a / sqrt(2 * M_PI);

    debugw = w;
    debugl = l;
    debugm = m;

    T = (unsigned int*) malloc ( m * l * sizeof(int));
    assert(T != NULL);

    unsigned int index = 0;
    for (unsigned int i = 0; i < m; i++)
        for (unsigned int j = 0; j < l; j++)
            T[index++] = next_sample(sigma); 

    seed_X = NULL;
    mem_Y = NULL;

    cout << "Dimension of a plaintext vector: " << m << endl;
    cout << "Size of a plaintext element in the vector: " << t << endl;
    cout << "Size of a ciphertext element in the ciphertext vector: " << q << endl;
    cout << "Length of the ciphertext vector: " << n << endl;
    cout << "Size of digits of a ciphertext element: " << d << endl;
    cout << "Number of digits of a ciphertext element: " << L << endl; 
    cout << "Promotion of the plaintext: " << w << endl;
    cout << "Expected bound on the noise: " << B << endl;
    cout << "Alpha in (Regev's) gaussian distribution: " << a << endl;

    mul_ee_pre();

}

xhe::~xhe()
{
    if (T!= NULL) free(T);
    if (seed_X != NULL) free(seed_X);
    if (mem_Y != NULL)
    {
        for(unsigned int i = 0; i < L; i++)
        {
             if(mem_Y[i] != NULL)
                 free(mem_Y[i]);
        }
        free(mem_Y);
    }
}

void xhe::mul_ee_pre()
{
    cout << "mul_ee_pre() starts" << endl;

    unsigned int* Sstar = (unsigned int *)malloc(sizeof(unsigned int) * m * n * n);
    assert(Sstar != NULL);

    unsigned int row_identity[m];

    for(unsigned int i = 0; i < m; i++)
        row_identity[i] = 0;

    //Prepare matrix S*
    cout << "Prepare matrix S*" << endl;
    for(unsigned int i = 0; i < m; i++)
    {
        //Prepare the ith row of identity
        row_identity[i] = 1;
        
        unsigned int index = 0;

        for(unsigned int j = 0; j < m; j++)
        {
            for(unsigned int k = 0; k < m; k++)
                Sstar[i * n * n + (index++)] = row_identity[j] * row_identity[k];
            for(unsigned int k = 0; k < l; k++)
                Sstar[i * n * n + (index++)] = row_identity[j] * T[i * l + k];
        }

        for(unsigned int j = 0; j < l; j++)
        {
            for(unsigned int k = 0; k < m; k++)
                Sstar[i * n * n + (index++)] = T[i * l + j] * row_identity[k];
            for(unsigned int k = 0; k < l; k++)
                Sstar[i * n * n + (index++)] = T[i * l + j] * T[i * l + k];
        }

        //Prepare the (i+1)th row of identity
        row_identity[i] = 0;
    }

    //Allocate seeds of X and matrices of Y
    cout << "Allocate seed_X and mem_Y" << endl;
    seed_X = (unsigned int*)malloc(sizeof(unsigned int) * L);
    mem_Y = (unsigned int**)malloc(sizeof(unsigned int*) * L);

    double size_X = sizeof(unsigned int) * L;
    double size_Y = sizeof(unsigned int*) * L + sizeof(unsigned int) * m * n * n * L;
    cout << "Memory = " << (size_X + size_Y)/(1 << 20) << "MBytes" << endl;

    unsigned int* X = (unsigned int*)malloc(sizeof(unsigned int) * l * n * n);
    unsigned int* E = (unsigned int*)malloc(sizeof(unsigned int) * m * n * n);

    assert(X != NULL);
    assert(E != NULL);

    cout << "Calculate seed_X and mem_Y" << endl;
    for(unsigned int i = 0; i < L; i++)
    {
        //Create a strong random seed
        unsigned int seed;
        NTL::RandomLen((long&)seed, 32);
        srand(seed);

        seed_X[i] = seed;

        //Create matrix X
        for(unsigned int k = 0; k < n * n; k++)
            for(unsigned int j = 0; j < l; j++)
                X[j * n * n + k] = rand();
        //Create matrix E
        unsigned int index_E = 0;
        for(unsigned int j = 0; j < m; j++)
            for(unsigned int k = 0; k < n * n; k++)
                E[index_E++] = next_sample(sigma);

        //Allocate matrix Y
        unsigned int* Y = (unsigned int*)malloc(sizeof(unsigned int) * m * n * n);
        assert(Y != NULL);

        //Y = S* + E - TX
        unsigned int index_Y = 0, index_T = 0; //warning: when m * n * n is too large, the two indices could overflow.
        for(unsigned int j = 0; j < m; j++)
            for(unsigned int k = 0; k < n * n; k++)
            {
                Y[k*m+j] = Sstar[j * n * n + k] + E[index_Y];
                for(unsigned int a = 0; a < l; a++)
                {
                    Y[k*m+j] -= T[j * l + a] * X[a * n * n + k]; 
                }
                index_Y++;
            }
        //Write the address of Y into mem_Y
        mem_Y[i] = Y;

        //S* = S* * d
        unsigned int index_S = 0;
        for(unsigned int j = 0; j < m; j++)
            for(unsigned int k = 0; k < n * n; k++)
                Sstar[index_S++] <<= logd;
    }

    //Deallocate X and E
    if(X!= NULL) free(X);
    if(E!= NULL) free(E);

    //Deallocate S
    if(Sstar!= NULL) free(Sstar);

    cout << "mul_ee_pre() ends" << endl;

    return;
}

void xhe::encrypt(unsigned int * ct, const unsigned int * pt)
{
    unsigned int X[l];
    unsigned int E[m];
    for(unsigned int i = 0; i < l; i++)
    {
        X[i] = rand();
    }
    for(unsigned int i = 0; i < m; i++)
    {
        E[i] = next_sample(sigma);
    }    

    //Y = w * pt + E - T * X;    
    unsigned int Y[m];
    for(unsigned int i = 0; i < m; i++)
        Y[i] = (pt[i] << logw) + E[i];

    unsigned int tmp[m];
    unsigned int index = 0;
    for(unsigned int i = 0; i < m; i++)
    {
        tmp[i] = 0;
        for(unsigned int j = 0; j < l; j++)
            tmp[i] += T[index++] * X[j];
    }
    
    for(unsigned int i = 0; i < m; i++)
        ct[i] = Y[i] - tmp[i];
    for(unsigned int i = 0; i < l; i++)
        ct[i + m] = X[i];

    return;
}

void xhe::decrypt(unsigned int * pt, const unsigned int * ct)
{
    unsigned int tmp[m];
    double d[m];

    //tmp = T * X;
    unsigned int index = 0;
    for(unsigned int i = 0; i < m; i++)
    {
        tmp[i] = 0;
        for(unsigned int j = 0; j < l; j++)
            tmp[i] += T[index++] * ct[j + m];
    }

    //tmp = tmp + Y;
    for(unsigned int i = 0; i < m; i++)
        tmp[i] += ct[i];

    for(unsigned int i = 0; i < m; i++)
        pt[i] = (unsigned int)round(1.0 * tmp[i] / w);

    return;
}

void xhe::encrypt_matrix_once(unsigned int ** ct, unsigned int ** pt)
{
    unsigned int pt_reorganized[m][m];
    for(unsigned int i = 0; i < m; i++)
    {
        for(unsigned int j = 0; j < m; j++)
        {
            pt_reorganized[i][j] = pt[j][(i+j)%m];
        }
    }

    for(unsigned int i = 0; i < m; i++)
    {
        encrypt(ct[i], pt_reorganized[i]);
    }

    return;
}

void xhe::decrypt_matrix_once(unsigned int ** pt, unsigned int ** ct)
{
    unsigned int pt_reorganized[m][m];
    for(unsigned int i = 0; i < m; i++)
    {
        decrypt(pt_reorganized[i], ct[i]);
    }
    for(unsigned int i = 0; i < m; i++)
    {
        for(unsigned int j = 0; j < m; j++)
        {
            pt[j][(i+j)%m] = pt_reorganized[i][j];
        }
    }

    return;
}


void xhe::encrypt_vector_once(unsigned int ** ct, unsigned int * pt)
{
    unsigned int pt_tmp[2 * m];
    for(unsigned int i = 0; i < m; i++)
    {
        pt_tmp[i] = pt[i];
    }
    for(unsigned int i = 0; i < m; i++)
    {
        pt_tmp[i+m] = pt[i];
    }
    for(unsigned int i = 0; i < m; i++)
    {
        encrypt(ct[i], pt_tmp + i);
    }

    return;
}

void xhe::decrypt_vector_once(unsigned int * pt, unsigned int ** ct)
{
    decrypt(pt, ct[0]);
}

void xhe::add_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2)
{
    for(unsigned int i = 0; i < n; i++)
        ct[i] = ct1[i] + ct2[i];
}

void xhe::mul_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2)
{
    mul_ee_v1(ct, ct1, ct2);
    return;
}

void xhe::mul_ee_v1(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2)
{
    unsigned int * prod_round = (unsigned int*) malloc(sizeof(unsigned int) * n * n);
    assert(prod_round != NULL);

    unsigned int index = 0;
    for(unsigned int i = 0; i < n; i++)
        for(unsigned int j = 0; j < n; j++)
        {
            prod_round[index++] = (unsigned int)round(((unsigned long)ct1[i]) * ((unsigned long)ct2[j]) * 1.0 / w);
        }

    //save a seed
    unsigned int seed_old = rand();

    for(unsigned int i = 0; i < n; i++)
        ct[i] = 0;

    for(unsigned int i = 0; i < L; i++)
    {
        unsigned int* Y = mem_Y[i];

        srand(seed_X[i]);

        for(unsigned int k = 0; k < n * n; k++)
        {
            unsigned int j = 0;
            unsigned int digit = (prod_round[k] & (d-1));
            if(digit == 0)
            {
                for(; j < l; j++)
                    rand();     
            }
            else if(digit == 1)
            {
                for(; j < m; j++)
                {
                    ct[j] += Y[k*m+j];
                }

                for(; j < n; j++)
                {
                    ct[j] += rand();
                }  
            }
            else
            {
                for(; j < m; j++)
                {
                    ct[j] += Y[k*m+j] * digit;
                }

                for(; j < n; j++)
                {
                    ct[j] += rand() * digit;
                }  
            }
        }

        unsigned int j = n * n -1;
        do{
            prod_round[j] >>= logd;
        }while(j-- > 0);

    }

    if(prod_round != NULL) free(prod_round);

    //Recover an old seed
    srand(seed_old);

    return;
}

void xhe::mul_ee_v0(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2)
{
    unsigned long cross_prod[n * n];
    unsigned int index = 0;
    for(unsigned int i = 0; i < n; i++)
        for(unsigned int j = 0; j < n; j++)
        {
            cross_prod[index++] = ((unsigned long)ct1[i]) * ((unsigned long)ct2[j]);
        }

    unsigned int prod_round[n * n];
    for(unsigned int i = 0; i < n * n; i++)
    {
        prod_round[i] = (unsigned int)round(1.0 * cross_prod[i] / w);
    }

    unsigned int* X = (unsigned int*)malloc(sizeof(unsigned int) * l * n * n);
    assert(X != NULL);

    //save a seed
    unsigned int seed_old = rand();

    for(unsigned int i = 0; i < n; i++)
        ct[i] = 0;

    for(unsigned int i = 0; i < L; i++)
    {
        unsigned int seed = seed_X[i];
        unsigned int* Y = mem_Y[i];

        srand(seed);

        //Create matrix X
        for(unsigned int k = 0; k < n * n; k++)
            for(unsigned int j = 0; j < l; j++)
                X[j * n * n + k] = rand();

        unsigned int index_Y = 0;
        for(unsigned int j = 0; j < m; j++)
            for(unsigned int k = 0; k < n * n; k++)
            {
                ct[j] += Y[k*m+j] * (prod_round[k] & (d-1));
            }

        unsigned int index_X = 0;
        for(unsigned int j = m; j < n; j++)
            for(unsigned int k = 0; k < n * n; k++)
            {
                ct[j] += X[index_X++] * (prod_round[k] & (d-1));
            }

        for(unsigned int j = 0; j < n * n; j++)
            prod_round[j] >>= logd;

    }

    //Deallocate X
    if(X!= NULL) free(X);

    //Recover an old seed
    srand(seed_old);

    return;
}

void xhe::mul_ee_matrix_once(unsigned int * ct, unsigned int ** ct1, unsigned int ** ct2)
{
    mul_ee_matrix_once_v1(ct, ct1, ct2);
}

void xhe::mul_ee_matrix_once_v0(unsigned int * ct, unsigned int ** ct1, unsigned int ** ct2)
{
    unsigned int ct_tmp[m][n];
    for(unsigned int i = 0; i < m; i++)
    {
        mul_ee(ct_tmp[i], ct1[i], ct2[i]);
    }

    for(unsigned int j = 0; j < n; j++)
    {
        ct[j] = 0;
    }

    for(unsigned int i = 0; i < m; i++)
        for(unsigned int j = 0; j < n; j++)
            ct[j] += ct_tmp[i][j];
    return;
}

void xhe::mul_ee_matrix_once_v1(unsigned int * ct, unsigned int ** ct1, unsigned int ** ct2)
{
    //Save a seed
    unsigned int seed_old = rand();

    //Allocate prod_round
    unsigned int ** prod_round = (unsigned int**) malloc(sizeof(unsigned int*) * m);
    assert(prod_round != NULL);
    for(unsigned int a = 0; a < m; a++)
    {
        prod_round[a] = (unsigned int*)malloc(sizeof(unsigned int) * n * n);
        assert(prod_round[a]);
    }

    //Compute the cross product and round the cross product
    for(unsigned int a = 0; a < m; a++)
    {
        unsigned int index = 0;
        for(unsigned int i = 0; i < n; i++)
            for(unsigned int j = 0; j < n; j++)
            {
                prod_round[a][index++] = (unsigned int)round(((unsigned long)ct1[a][i]) * ((unsigned long)ct2[a][j]) * 1.0 / w);
            }
    }

    //Initialize ct
    for(unsigned int i = 0; i < n; i++)
        ct[i] = 0;

    //Start to use the L key-switching matrices
    for(unsigned int i = 0; i < L; i++)
    {
        unsigned int* Y = mem_Y[i];

        srand(seed_X[i]);

        for(unsigned int k = 0; k < n * n; k++)
        {
            //Sum up the digits of prod_round[a][k] for all a in [m]
            unsigned int digit = 0;
            for(unsigned int a = 0; a < m; a++) digit += (prod_round[a][k] & (d-1)); //Todo: change the storage of prod_round

            //The most expensive operations
            unsigned int j = 0;

            for(; j < m; j++)
            {
                ct[j] += Y[k*m+j] * digit;
            }

            for(; j < n; j++)
            {
                ct[j] += rand() * digit;
            }   
        }

        //The for loop is optimized to a while loop
        unsigned int a = m - 1;
        do
        {
            unsigned int j = n * n -1;
            do{
                prod_round[a][j] >>= logd;
            }while(j-- > 0);
        }while(a-- > 0);

    }

    //Deallocate prod_round
    for(unsigned int a = 0; a < m; a++)
    {
        if(prod_round[a] != NULL) free(prod_round[a]);
    }
    if(prod_round != NULL) free(prod_round);

    //Recover an old seed
    srand(seed_old);

    return;
}

