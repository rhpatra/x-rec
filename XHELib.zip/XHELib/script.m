t = 35;
logq = 32;
alpha = 1.41753e-10;
epsilon = 2**(-30);

part1 = log(epsilon/692.39)/ (-9.8356 * alpha);
part2 = 6.4322;

part3 = (log(part1)/log(part2))**2;

n = (part3 * (t + 110))/logq
