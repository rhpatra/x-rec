Files xhe.h, xhe.cpp implement an encryption scheme XHE of integers.

Interface:

1. Constructor and destructor

xhe(unsigned int _logt);
~xhe();

2. Encrypting and calculating vectors

void encrypt(unsigned int * ct, const unsigned int * pt);
void decrypt(unsigned int * pt, const unsigned int * ct);
void add_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);
void sub_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);
void mul_ee(unsigned int * ct, const unsigned int * ct1, const unsigned int * ct2);

3. Encrypting matrices and calculating between a matrix and a vector. The two ciphertexts of the matrix and the vector respectively are prepared in a way such that the resulting ct of mul_ee_matrix_once can be decrypted by decrypt(pt, ct)

void encrypt_matrix_once(unsigned int ** ct, unsigned int ** pt);
void encrypt_vector_once(unsigned int ** ct, unsigned int * pt);
void decrypt_matrix_once(unsigned int ** pt, unsigned int ** ct);
void decrypt_vector_once(unsigned int * pt, unsigned int ** ct);
void mul_ee_matrix_once(unsigned int * ct, unsigned int ** ct1, unsigned int ** ct2);

Parameters:

1. Parameters are fixed for logt (the number of bits of each plaintext) = 8, and m (the length of a plaintext vector) = 10;

2. logq = 32; q = 2^32; l = 736; n = 746; logw = 24; logd = 8; d = 256; w = 2^24; L = 4;

3. Bound B of the noise distribution is the solution of the following equation:

a_eq * B^2 + b_eq * B + c_eq = 0

where b_eq = 4 * t * ( 0.5 * l + 2 * sqrt(l) ), a_eq = l, c_eq = -w;

4. Regev's gaussian distribution is used with a (alpha) = 1.0 * B / (6 * q);

5. How to decide l: script.m takes an estimated alpha and the known logq to produce l. The logt of the number of seconds is set to 35. The distinguishing advantage is set to 2^(-30).

(As mentioned in Lenstra��s discussion about the key sizes, a good choice of security parameters ensures 40M dollardays as a cost for attacks. Assuming
that the AMD Opteron machine costs 55$, 2^35 seconds on that machine requires 39.98M dollardays.)

6. Current parameters lead to the storage of 85MB for key-switching matrices of mul_ee and/or mul_ee_matrix_once.