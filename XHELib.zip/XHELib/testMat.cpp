#include "xhe.h"
#include <time.h>
#include <limits.h>
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include <iostream>
#include <NTL/ZZ.h>

using namespace std;

#define BILLION 1000000000L

uint64_t acctime = 0;
struct timespec start;
struct timespec end1;
uint64_t elapsedTime;

#define TIMER_START clock_gettime(CLOCK_MONOTONIC, &start);

#define TIMER_END clock_gettime(CLOCK_MONOTONIC, &end1);elapsedTime = BILLION * (end1.tv_sec - start.tv_sec) + end1.tv_nsec - start.tv_nsec; acctime += elapsedTime;

#define TIMER_PRINT cout << acctime << " ns.\n";

int main()
{ 
    xhe o(8);
    unsigned int k = 0, m = o.m, l = o.l, n = o.n, logt = o.logt;

    unsigned int pt[m][m];
    unsigned int ct[m][n];
    unsigned int vec_pt[m];
    unsigned int vec_ct[n];
    unsigned int vec_ct_vec[m][n];
    unsigned int res_pt[m];
    unsigned int res_hatpt[m];
    unsigned int res_ct[n];
    unsigned int hatpt[m][m];

    unsigned int * ptr_pt[m];
    unsigned int * ptr_hatpt[m];
    unsigned int * ptr_ct[m];
    unsigned int * ptr_ct_vec[m];

    for(unsigned int i = 0; i < m; i++)
    {
        ptr_pt[i] = pt[i];
        ptr_ct[i] = ct[i];
        ptr_ct_vec[i] = vec_ct_vec[i];
        ptr_hatpt[i] = hatpt[i];
    }

    //Test encryption and decryption
    cout << "Test Encryption of a Matrix of " << logt << "-bit Integers." << endl;

while ( k < (1 << logt))
{
    k++;

    //Prepare a plaintext
    for(unsigned int i = 0; i < m; i++)
    {
        for(unsigned int j = 0; j < m; j++)
        {
            pt[i][j] = rand() & ((1 << logt) - 1);
        }
    }

    //Encrypt a plaintext (matrix)
    o.encrypt_matrix_once(ptr_ct, ptr_pt);
 
    //Decrypt a ciphertext (matrix)
    o.decrypt_matrix_once(ptr_hatpt, ptr_ct);

    //Check equality (matrix)
    bool isEqual = true;
    for(unsigned int i = 0; i < m; i++)
    {
        for(unsigned int j = 0; j < m; j++)
        {
            if( ( hatpt[i][j]  & ( (1 << logt) - 1 ) ) != pt[i][j]) {isEqual = false; break;}
        }
    }

    if(!isEqual)
    {
        cout << "hatpt = " << endl;
        for(unsigned int i = 0; i < m; i++)
        {
            for(unsigned int j = 0; j < m; j++)
            {
                cout << hatpt[i][j] << "\t";
            }
            cout << "\n";
        }
        cout << "---------------" << endl;

        cout << "pt = " << endl;
        for(unsigned int i = 0; i < m; i++)
        {
            for(unsigned int j = 0; j < m; j++)
            {
                cout << pt[i][j] << "\t";
            }
            cout << "\n";
        }
        cout << "---------------" << endl;

    }

}

    //Test multiplication
    cout << "Test Multiplication Between a Matrix of " << logt << "-bit Integers And a Vector of " << logt << "-bit Integers" << endl;

k = 0;

TIMER_START
while(k < (1 << logt))
{
    k++;

    //Prepare a plaintext
    for(unsigned int i = 0; i < m; i++)
    {
        for(unsigned int j = 0; j < m; j++)
        {
            pt[i][j] = rand() & ((1 << logt) - 1);
        }
        vec_pt[i] = rand() & ((1 << logt) - 1);
    }

    //Encrypt a plaintext (matrix)
    o.encrypt_matrix_once(ptr_ct, ptr_pt);

    //Encrypt a vector (matrix)
    o.encrypt_vector_once(ptr_ct_vec, vec_pt);

    //Multiply two ciphertexts
    o.mul_ee_matrix_once(res_ct, ptr_ct, ptr_ct_vec);

    //Decrypt a ciphertext
    o.decrypt(res_hatpt, res_ct);

    //Check equality
    for(unsigned int i = 0; i < m; i++)
    {
        unsigned int elem = 0;
        for(unsigned int j = 0; j < m; j++)
        {
            elem += pt[i][j] * vec_pt[j];
        }
        elem = elem & ((1 << logt) - 1);

        res_pt[i] = elem;
    }

    bool IsEqual = true;
    for(unsigned int i = 0; i < m; i++)
        if(( res_hatpt[i]  & ( (1 << logt) - 1 ) )  != res_pt[i] )
        {
            IsEqual = false;
            break;
        }
    if(!IsEqual)
    {
        cout << "res_hatpt = \n[" << endl;
        for(unsigned int i = 0; i < m; i++)
            cout << res_hatpt[i] << ", ";    
        cout << "]\n" << endl;
        cout << "res_pt = \n[" << endl;
        for(unsigned int i = 0; i < m; i++)
            cout << res_pt[i] << ", ";    
        cout << "]\n" << endl;
    }
}

TIMER_END
cout << acctime/k << " ns.\n";

    return 0;
}
